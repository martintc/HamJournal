package com.hamjournal;

public class User {

	protected String callSign;
	
	/* public User(String arg1, String arg2, String arg3) {
		callSign = arg1;
		license = arg2;
		directoryPath = arg3;
	} */
	
	public User(String arg1) {
		callSign = arg1;
	}
	
}
