sudo java -jar /opt/HamJournal/HamJournal.jar
