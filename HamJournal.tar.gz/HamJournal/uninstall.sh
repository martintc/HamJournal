echo "Removing HamJournal"
echo "**********"
sudo rm -rv /opt/HamJournal
sudo rm -rfv /usr/bin/Hamjournal

echo "Done!"
